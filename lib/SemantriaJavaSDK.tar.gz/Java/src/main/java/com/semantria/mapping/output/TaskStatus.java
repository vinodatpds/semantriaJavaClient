package com.semantria.mapping.output;

public enum TaskStatus
{
	QUEUED,
	PROCESSED,
	CANCELED,
	FAILED,
	IN_SERVICE
}